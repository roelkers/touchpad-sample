  // Your web app's Firebase configuration
 export default {
    apiKey: "AIzaSyCWd7zfUYHVjFMjrXFCYLRm5pkAaJLUjQo",
    authDomain: "touchpad-sample.firebaseapp.com",
    databaseURL: "https://touchpad-sample.firebaseio.com",
    projectId: "touchpad-sample",
    storageBucket: "touchpad-sample.appspot.com",
    messagingSenderId: "151598672245",
    appId: "1:151598672245:web:760014372e999356d30b3c"
  };